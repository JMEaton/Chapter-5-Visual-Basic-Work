﻿Public Class Form1
    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        Const PROMPT1 As String = "Enter first name"
        Const PROMPT2 As String = "Enter last name"
        Dim fName As String
        Dim lName As String

        fName = InputBox(PROMPT1)
        lName = InputBox(PROMPT2)

        Me.lblFullName.Text = fName & Space(1) & lName
    End Sub
End Class
