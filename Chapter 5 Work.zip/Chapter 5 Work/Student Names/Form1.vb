﻿Public Class Form1
    Private Sub btnAddNames_Click(sender As Object, e As EventArgs) Handles btnAddNames.Click
        Const NUM_Names As Integer = 5
        Dim stuNames(NUM_Names - 1) As String

        For nameCount As Integer = 0 To stuNames.Length - 1
            stuNames(nameCount) = InputBox("Enter stundent's first name:", "Students")
        Next nameCount

        For nameCount As Integer = 0 To stuNames.Length - 1
            Me.lstStuNames.Items.Add(stuNames(nameCount))
        Next nameCount
    End Sub
End Class
