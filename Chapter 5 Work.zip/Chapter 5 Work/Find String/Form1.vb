﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim searchtext As String = Me.txtTextEntered.Text
        Dim parameters As String = Me.txtSearchText.Text
        Dim position As Integer

        position = searchtext.IndexOf(parameters)

        Me.lblResult.Text = position
    End Sub

    Private Sub txtSearchText_TextChanged(sender As Object, e As EventArgs) Handles txtSearchText.TextChanged
        Me.lblResult.Text = Nothing
    End Sub

    Private Sub txtTextEntered_TextChanged(sender As Object, e As EventArgs) Handles txtTextEntered.TextChanged
        Me.lblResult.Text = Nothing
    End Sub
End Class
