﻿Public Class Form1
    Private Sub btnCompare_Click(sender As Object, e As EventArgs) Handles btnCompare.Click
        Dim firstWord As String
        Dim secondWord As String

        firstWord = Me.txtFirstWord.Text
        secondWord = Me.txtSecondWord.Text

        Select Case String.Compare(firstWord, secondWord, True)
            Case 0
                Me.lblResult.Text = "The same"
            Case Is < 0
                Me.lblResult.Text = firstWord & " " & "comes before" & " " & secondWord
            Case Is < 0
                Me.lblResult.Text = firstWord & " " & "comes after" & " " & secondWord
        End Select
    End Sub

    Private Sub txtFirstWord_TextChanged(sender As Object, e As EventArgs) Handles txtFirstWord.TextChanged
        Me.lblResult.Text = Nothing
    End Sub

    Private Sub txtSecondWord_TextChanged(sender As Object, e As EventArgs) Handles txtSecondWord.TextChanged
        Me.lblResult.Text = Nothing
    End Sub
End Class
