﻿Public Class Form1
    Private Sub btnCount_Click(sender As Object, e As EventArgs) Handles btnCount.Click
        Dim count As Integer = 0
        Dim letter As Char

        letter = Me.txtEnterChar.Text

        For Each ch As Char In Me.txtEnterText.Text
            If ch = letter Then
                count += 1
            End If
        Next

        Me.lblLetterCountMessage.Text = "Number of Times the letter occurs:  " & count
    End Sub

    Private Sub txtEnterChar_TextChanged(sender As Object, e As EventArgs) Handles txtEnterChar.TextChanged
        Me.lblLetterCountMessage.Text = Nothing
    End Sub

    Private Sub txtEnterText_TextChanged(sender As Object, e As EventArgs) Handles txtEnterText.TextChanged
        Me.lblLetterCountMessage.Text = Nothing
    End Sub
End Class
