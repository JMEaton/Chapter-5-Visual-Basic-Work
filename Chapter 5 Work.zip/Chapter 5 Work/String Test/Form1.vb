﻿Public Class Form1
    Private Sub btnData_Click(sender As Object, e As EventArgs) Handles btnData.Click
        Dim text As String = Me.txtEnterText.Text

        Me.lblFirstLetter.Text = text.Substring(0)
        Me.lblLastLetter.Text = text.Substring(text.Length - 1)
        Me.lblMiddleLetter.Text = text.Substring(text.Length / 2)
    End Sub

    Private Sub txtEnterText_TextChanged(sender As Object, e As EventArgs) Handles txtEnterText.TextChanged
        Me.lblFirstLetter.Text = Nothing
        Me.lblLastLetter.Text = Nothing
        Me.lblMiddleLetter.Text = Nothing
    End Sub
End Class
