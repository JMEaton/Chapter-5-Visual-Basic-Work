﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim number As Integer = 1
        Dim answer As Integer = 1

        number = Val(Me.txtNumberEntered.Text)
        For count As Integer = 1 To number
            answer += count / 2
        Next count

        Me.lblAnswer.Text = answer
    End Sub

    Private Sub txtNumberEntered_TextChanged(sender As Object, e As EventArgs) Handles txtNumberEntered.TextChanged
        Me.lblAnswer.Text = Nothing
    End Sub
End Class
