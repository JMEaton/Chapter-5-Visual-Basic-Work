﻿Public Class Form1
    Private Sub btnPlayGame_Click(sender As Object, e As EventArgs) Handles btnPlayGame.Click
        Const SECRET_WORD As String = "VELOCITY"
        Const FLAG As Char = "!"
        Const GUESS_PROMPT As String = "Enter a letter or " & FLAG & " to guess word."
        Dim numGueses As Integer = 0
        Dim letterGuess As Char
        Dim wordGuess As String
        Dim tempWord As String
        Dim score As Integer = 100
        Dim endGame As Boolean

        Dim wordguessedSoFar As String = ""
        Dim length As Integer = SECRET_WORD.Length
        wordguessedSoFar = wordguessedSoFar.PadLeft(length, "-")
        Me.lblSecretWord.Text = wordguessedSoFar

        Dim templetterGuess = InputBox(GUESS_PROMPT, score, Me.Text)
        If templetterGuess = Nothing Then
            endGame = True
        Else
            letterGuess = templetterGuess
        End If

        Do While letterGuess <> FLAG And wordguessedSoFar <> SECRET_WORD And Not endGame
            numGueses += 1
            score -= 10
            For letterPos As Integer = 0 To SECRET_WORD.Length - 1
                If SECRET_WORD.Chars(letterPos) = Char.ToUpper(letterGuess) Then
                    tempWord = wordguessedSoFar.Remove(letterPos, 1)
                    wordguessedSoFar = tempWord.Insert(letterPos, Char.ToUpper(letterGuess))
                    Me.lblSecretWord.Text = wordguessedSoFar
                End If
            Next letterPos
            If wordguessedSoFar <> SECRET_WORD Then
                templetterGuess = InputBox(GUESS_PROMPT, Me.Text)
                If templetterGuess = Nothing Then
                    endGame = True
                End If
            End If
        Loop

        If wordguessedSoFar = SECRET_WORD Then
            MessageBox.Show("You guessed it in " & numGueses & " guesses " & "Your score is " & score)
        ElseIf letterGuess = FLAG Then
            wordGuess = InputBox("Enter a word: ", Me.Text)
            If wordGuess.ToUpper = SECRET_WORD Then
                MessageBox.Show("You guessed it in " & numGueses & " guesses " & "Your score is " & score) )
                Me.lblSecretWord.Text = SECRET_WORD
            Else
                MessageBox.Show("Sorry you lose")
            End If
        Else
            MessageBox.Show("Game over.")
        End If
    End Sub
End Class
